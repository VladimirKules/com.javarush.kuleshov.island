package enumeration;

public enum AnimalType {
    BULL,
    CATERPILLAR,
    DEER,
    DUCK,
    GOAT,
    HORSE,
    MOUSE,
    RABBIT,
    SHEEP,
    WILDBOAR,
    BEAR,
    EAGLE,
    FOX,
    SNAKE,
    WOLF

}
